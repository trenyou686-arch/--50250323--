"""
Experimental Python code for the paper:
Artificial Intelligence Empowering Educational, Teaching and Learning Innovation
Student: Jeon Inwoo / 田仁友, ID: 50250323

Purpose:
This script supports case-coding analysis. It reads a CSV file containing coded cases of AI education practice,
computes descriptive summaries by application scenario and education stage, and generates basic figures.
Replace the sample CSV path and coding values with your verified research data.
"""
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

DATA_PATH = Path("case_coding_ai_education.csv")
OUTPUT_DIR = Path("analysis_outputs")
OUTPUT_DIR.mkdir(exist_ok=True)

score_cols = ["theory_score", "practice_score", "ethics_score", "equity_score", "scalability_score"]


def load_data(path: Path) -> pd.DataFrame:
    if not path.exists():
        sample = pd.DataFrame([
            {"case_id": "C01", "education_stage": "Higher education", "application_scenario": "Personalized learning", "theory_score": 4, "practice_score": 4, "ethics_score": 3, "equity_score": 3, "scalability_score": 4},
            {"case_id": "C02", "education_stage": "Basic education", "application_scenario": "Intelligent assessment", "theory_score": 4, "practice_score": 3, "ethics_score": 3, "equity_score": 3, "scalability_score": 3},
            {"case_id": "C03", "education_stage": "Vocational education", "application_scenario": "Simulation training", "theory_score": 3, "practice_score": 4, "ethics_score": 3, "equity_score": 2, "scalability_score": 3},
            {"case_id": "C04", "education_stage": "Special education", "application_scenario": "Assistive AI", "theory_score": 4, "practice_score": 3, "ethics_score": 4, "equity_score": 5, "scalability_score": 3},
        ])
        sample.to_csv(path, index=False, encoding="utf-8-sig")
        print(f"Sample coding file created: {path}")
    return pd.read_csv(path)


def summarize(df: pd.DataFrame) -> None:
    scenario_summary = df.groupby("application_scenario")[score_cols].mean().round(2)
    stage_summary = df.groupby("education_stage")[score_cols].mean().round(2)
    scenario_summary.to_csv(OUTPUT_DIR / "scenario_summary.csv", encoding="utf-8-sig")
    stage_summary.to_csv(OUTPUT_DIR / "stage_summary.csv", encoding="utf-8-sig")
    print("Scenario summary:")
    print(scenario_summary)
    print("
Stage summary:")
    print(stage_summary)

    ax = scenario_summary.plot(kind="bar", figsize=(11, 6))
    ax.set_title("AI Education Case Coding Results by Scenario")
    ax.set_xlabel("Application scenario")
    ax.set_ylabel("Average score (1-5)")
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "scenario_scores.png", dpi=300)
    plt.close()


if __name__ == "__main__":
    df = load_data(DATA_PATH)
    missing = [c for c in score_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing score columns: {missing}")
    summarize(df)
    print(f"Analysis outputs saved in: {OUTPUT_DIR.resolve()}")
